# Simple-note
A very simple web-based, mobile-friendly note app using localstorage to store data.
